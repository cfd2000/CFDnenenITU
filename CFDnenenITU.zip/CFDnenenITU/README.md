# AKCrack

Very Simple Algorithm...

Just attack by your dictionary password files...

How its work..?

1. Extract it in the Storage.
2. Locate on that folder.
3. Copy your dictionary file in the same directory as "passwords.txt"
4. Copy your ZIP file in the same directory as "encrypted.zip"
5. Run the "crack.py" file...

Wow... You did it...😃😃

Subscribe our channel for more...
http://m.youtube.com/techtipstricksbd
